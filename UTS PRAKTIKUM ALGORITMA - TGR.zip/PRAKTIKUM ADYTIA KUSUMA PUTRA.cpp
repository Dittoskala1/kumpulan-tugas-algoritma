#include <iostream>

using namespace std;

int main()
{
   int MIGR = 25000, NSGR = 22000, STAY = 20000, JM = 10000, AP = 1000, KP = 5000;     
    
   string namapemesan, kodemakanan, kodeminuman, kodejenisminuman, tingkatpedas,kodepedas, makanan, minuman, SP, PS, TP, DG, PN, HT;
   
   int jumlahmakanan, jumlahminuman, nominal,total,kembalian;
   
   int hargamakanan,hargaminuman;
   
   int hasilmakanan = 0, hasilminuman = 0;
   
   //INPUT MANG
   
    cout <<"nama pemesan :";
    cin >> namapemesan;
   
    cout <<"kode makanan:";
    cin >> kodemakanan;
   
    cout <<"kode minuman:";
    cin >> kodeminuman;
    
    cout <<"kode jenis minuman:";
    cin >> kodejenisminuman;
   
    cout <<"tingkat pedas:";
    cin >> tingkatpedas;
   
    cout <<"jumlah makanan:";
    cin >> jumlahmakanan;
   
    cout <<"jumlah minuman:";
    cin >> jumlahminuman;
   
    cout <<"nominal:";
    cin >> nominal;
    
    
    
    // MAKANAN
    
   if (kodemakanan == "MIGR")
    {
       makanan = "mie goreng";
       hasilmakanan = MIGR * jumlahmakanan;
    }
        else if (kodemakanan == "NSGR")
    {
        makanan = "nasi goreng";
        hasilmakanan = NSGR * jumlahmakanan;
    }
        else if (kodemakanan == "STAY")
    {
        makanan = "soto ayam";
        hasilmakanan = STAY * jumlahmakanan;
    }
    // MINUMAN 
    
    if (kodeminuman == "JM")
    {
        minuman = "jus mangga";
        hasilminuman = JM * jumlahminuman;
    }
        else if (kodeminuman == "AP")
    {
        minuman = "air putih";
        hasilminuman = AP * jumlahminuman;
    }
        else if (kodeminuman == "KP")
    {
        minuman = "kopi";
        hasilminuman = KP * jumlahminuman;
    }    
    
    // KODE PEDAS SLUR
   
    if (kodepedas == SP)
    {
        kodepedas = "sangat pedas";
    }
    else if (kodepedas == PS)
    {
        kodepedas = "pedas";
    }
    else if (kodepedas == TP)
    {
        kodepedas = "tidak pedas";
    }
   
    //JENIS MINUMAN SLUR
    
    if(kodeminuman == DG)
    {
    kodeminuman = "dingin";
    }
    else if(kodeminuman == PN)
    {
    kodeminuman = "panas";
    }
    else if(kodeminuman ==HT)
    {
    kodeminuman = "hangat";
    }
    //TOTAL HARGA 
    
    total = (hasilmakanan * jumlahmakanan) + (hasilminuman * jumlahminuman);
    kembalian = nominal - total;
    
    
    cout << "!! PESANAN NYA NIH BANG !!" <<endl <<endl ;
    
    cout << " pesanan namanya siapa" << namapemesan << endl;
    cout << jumlahmakanan << " " << makanan<< " " << tingkatpedas<< endl;
    cout << jumlahminuman << " " << minuman<< " " << kodejenisminuman<< endl;
    cout << "total pesanan  :" << total<< endl;
    cout << "kembalian :" << kembalian << endl;

    return 0;
}
